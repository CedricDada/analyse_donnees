Resume du cours
===============

une ligne dans un profil ligne represente une modalite de X

comment faire l'ACP sur les profils lignes
